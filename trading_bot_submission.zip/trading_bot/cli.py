from __future__ import annotations

import argparse
import getpass
import os
import sys
from dataclasses import asdict
from decimal import Decimal
from pathlib import Path
from typing import Any

try:
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover - depends on the active environment
    def load_dotenv(dotenv_path: str | Path | None = None, *_args: object, **_kwargs: object) -> bool:
        path = Path(dotenv_path or ".env")
        if not path.exists():
            return False
        for line in path.read_text(encoding="utf-8").splitlines():
            key, separator, value = line.partition("=")
            if separator and key and not key.lstrip().startswith("#"):
                os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))
        return True

from .bot.exceptions import BinanceAPIError, BinanceRequestError, ValidationError
from .bot.logging_config import configure_logging
from .bot.orders import OrderService, summarize_order_response
from .bot.validators import OrderRequest, ensure_client_order_id, validate_order_request


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="trading-bot",
        description="Place Binance USDT-M Futures Testnet orders from the CLI.",
    )
    parser.add_argument(
        "--symbol",
        required=True,
        help="Trading symbol, for example BTCUSDT.",
    )
    parser.add_argument(
        "--side",
        required=True,
        choices=("BUY", "SELL"),
        type=str.upper,
        help="Order side.",
    )
    parser.add_argument(
        "--type",
        "--order-type",
        dest="order_type",
        required=True,
        choices=("MARKET", "LIMIT"),
        type=str.upper,
        help="Order type.",
    )
    parser.add_argument(
        "--quantity",
        required=True,
        help="Positive order quantity, for example 0.001.",
    )
    parser.add_argument(
        "--price",
        help="Positive order price. Required for LIMIT orders.",
    )
    parser.add_argument(
        "--time-in-force",
        default="GTC",
        choices=("GTC", "IOC", "FOK", "GTX"),
        type=str.upper,
        help="Time in force for LIMIT orders. Default: GTC.",
    )
    parser.add_argument(
        "--position-side",
        choices=("BOTH", "LONG", "SHORT"),
        type=str.upper,
        help="Position side. Use only when your account is configured for hedge mode.",
    )
    parser.add_argument(
        "--reduce-only",
        action="store_true",
        help="Submit the order as reduce-only.",
    )
    parser.add_argument(
        "--client-order-id",
        help="Optional custom client order id.",
    )
    parser.add_argument(
        "--response-type",
        default="RESULT",
        choices=("ACK", "RESULT"),
        type=str.upper,
        help="Binance response type. RESULT returns richer order details when available.",
    )
    parser.add_argument(
        "--base-url",
        default=os.getenv("BINANCE_FUTURES_BASE_URL", "https://testnet.binancefuture.com"),
        help="Binance Futures base URL. Defaults to the USDT-M testnet.",
    )
    parser.add_argument(
        "--api-key",
        default=os.getenv("BINANCE_API_KEY"),
        help="API key. Prefer BINANCE_API_KEY in your environment.",
    )
    parser.add_argument(
        "--api-secret",
        default=os.getenv("BINANCE_API_SECRET"),
        help="API secret. Prefer BINANCE_API_SECRET in your environment.",
    )
    parser.add_argument(
        "--recv-window",
        default=5000,
        type=int,
        help="Binance recvWindow in milliseconds. Default: 5000.",
    )
    parser.add_argument(
        "--timeout",
        default=10.0,
        type=float,
        help="HTTP timeout in seconds. Default: 10.",
    )
    parser.add_argument(
        "--max-retries",
        default=2,
        type=int,
        help="Retries for safe GET requests such as exchange info and time sync. POST orders are not retried.",
    )
    parser.add_argument(
        "--skip-exchange-validation",
        action="store_true",
        help="Skip Binance exchange filter checks before placing the order.",
    )
    parser.add_argument(
        "--no-time-sync",
        action="store_true",
        help="Skip Binance server time sync before signing the order.",
    )
    parser.add_argument(
        "--log-file",
        default="logs/trading_bot.log",
        help="Path to the JSONL log file. Default: logs/trading_bot.log.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate and print the request without sending it to Binance.",
    )
    return parser


def build_configure_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="trading-bot configure",
        description="Save Binance Futures Testnet credentials locally in .env.",
    )
    parser.add_argument("--api-key", help="Binance Futures Testnet API key.")
    parser.add_argument("--api-secret", help="Binance Futures Testnet API secret.")
    parser.add_argument(
        "--base-url",
        default="https://testnet.binancefuture.com",
        help="Binance Futures Testnet base URL.",
    )
    parser.add_argument(
        "--env-file",
        default=".env",
        help="Credentials file to create or update. Default: .env.",
    )
    return parser


def build_account_check_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="trading-bot account-check",
        description="Verify Binance Futures Testnet credentials.",
    )
    parser.add_argument(
        "--api-key",
        default=os.getenv("BINANCE_API_KEY"),
        help="API key. Prefer BINANCE_API_KEY in your environment.",
    )
    parser.add_argument(
        "--api-secret",
        default=os.getenv("BINANCE_API_SECRET"),
        help="API secret. Prefer BINANCE_API_SECRET in your environment.",
    )
    parser.add_argument(
        "--base-url",
        default=os.getenv("BINANCE_FUTURES_BASE_URL", "https://testnet.binancefuture.com"),
        help="Binance Futures base URL. Defaults to the USDT-M testnet.",
    )
    parser.add_argument("--recv-window", default=5000, type=int, help="Binance recvWindow in ms.")
    parser.add_argument("--timeout", default=10.0, type=float, help="HTTP timeout in seconds.")
    parser.add_argument("--max-retries", default=2, type=int, help="Retries for safe GET requests.")
    parser.add_argument(
        "--log-file",
        default="logs/trading_bot.log",
        help="Path to the JSONL log file. Default: logs/trading_bot.log.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0] == "configure":
        return configure_account(argv[1:])
    if argv and argv[0] in {"account-check", "check-account"}:
        return check_account(argv[1:])

    load_dotenv()
    parser = build_parser()
    args = parser.parse_args(argv)

    logger = configure_logging(Path(args.log_file))

    try:
        order_request = validate_order_request(
            symbol=args.symbol,
            side=args.side,
            order_type=args.order_type,
            quantity=args.quantity,
            price=args.price,
            time_in_force=args.time_in_force,
            position_side=args.position_side,
            reduce_only=args.reduce_only,
            client_order_id=args.client_order_id,
            new_order_resp_type=args.response_type,
        )
        order_request = ensure_client_order_id(order_request)
    except ValidationError as exc:
        logger.error("validation_error", extra={"event": "validation_error", "error": str(exc)})
        print(f"Failure: {exc}", file=sys.stderr)
        return 2

    print_order_request(order_request, dry_run=args.dry_run)

    if args.dry_run:
        logger.info(
            "dry_run_order_request",
            extra={"event": "dry_run_order_request", "order": _printable_order(order_request)},
        )
        print("\nSuccess: dry run completed. No order was sent.")
        return 0

    if not args.api_key or not args.api_secret:
        message = (
            "Missing API credentials. Set BINANCE_API_KEY and BINANCE_API_SECRET, "
            "or pass --api-key and --api-secret."
        )
        logger.error("credential_error", extra={"event": "credential_error", "error": message})
        print(f"\nFailure: {message}", file=sys.stderr)
        return 2

    try:
        from .bot.client import BinanceFuturesClient
    except ModuleNotFoundError as exc:
        if exc.name == "binance":
            message = "Missing dependency 'python-binance'. Run: pip install -r requirements.txt"
            logger.error("dependency_error", extra={"event": "dependency_error", "error": message})
            print(f"\nFailure: {message}", file=sys.stderr)
            return 1
        raise

    client = BinanceFuturesClient(
        api_key=args.api_key,
        api_secret=args.api_secret,
        base_url=args.base_url,
        recv_window=args.recv_window,
        timeout=args.timeout,
        max_retries=args.max_retries,
        logger=logger,
    )
    service = OrderService(
        client=client,
        validate_exchange_filters=not args.skip_exchange_validation,
        sync_time=not args.no_time_sync,
        logger=logger,
    )

    try:
        response = service.place_order(order_request)
    except ValidationError as exc:
        logger.error("validation_error", extra={"event": "validation_error", "error": str(exc)})
        print(f"\nFailure: {exc}", file=sys.stderr)
        return 2
    except BinanceAPIError as exc:
        logger.error(
            "binance_api_error",
            extra={
                "event": "binance_api_error",
                "status_code": exc.status_code,
                "error": str(exc),
                "response": exc.payload,
            },
        )
        print(f"\nFailure: Binance API error: {exc}", file=sys.stderr)
        return 1
    except BinanceRequestError as exc:
        logger.error("network_error", extra={"event": "network_error", "error": str(exc)})
        print(f"\nFailure: Network error: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:  # pragma: no cover - defensive CLI boundary
        logger.exception("unexpected_error", extra={"event": "unexpected_error"})
        print(f"\nFailure: Unexpected error: {exc}", file=sys.stderr)
        return 1

    summary = summarize_order_response(response)
    print_order_response(summary, response)
    print("\nSuccess: order accepted by Binance Futures Testnet.")
    return 0


def configure_account(argv: list[str] | None = None) -> int:
    parser = build_configure_parser()
    args = parser.parse_args(argv)

    api_key = args.api_key or input("Binance Futures Testnet API key: ").strip()
    api_secret = args.api_secret or getpass.getpass("Binance Futures Testnet API secret: ").strip()
    base_url = str(args.base_url).strip().rstrip("/")

    if not api_key or not api_secret:
        print("Failure: API key and API secret are required.", file=sys.stderr)
        return 2
    if base_url != "https://testnet.binancefuture.com":
        print(
            "Failure: this project is configured for Binance Futures Testnet only.",
            file=sys.stderr,
        )
        return 2

    env_path = Path(args.env_file)
    values = _read_env_values(env_path)
    values["BINANCE_API_KEY"] = api_key
    values["BINANCE_API_SECRET"] = api_secret
    values["BINANCE_FUTURES_BASE_URL"] = base_url
    _write_env_values(env_path, values)

    print(f"Success: credentials saved locally to {env_path}.")
    print("Next: run `python -m trading_bot account-check` to verify the link.")
    return 0


def check_account(argv: list[str] | None = None) -> int:
    load_dotenv()
    parser = build_account_check_parser()
    args = parser.parse_args(argv)
    logger = configure_logging(Path(args.log_file))

    if not args.api_key or not args.api_secret:
        message = (
            "Missing API credentials. Run `python -m trading_bot configure`, "
            "or set BINANCE_API_KEY and BINANCE_API_SECRET."
        )
        logger.error("credential_error", extra={"event": "credential_error", "error": message})
        print(f"Failure: {message}", file=sys.stderr)
        return 2

    try:
        from .bot.client import BinanceFuturesClient
    except ModuleNotFoundError as exc:
        if exc.name == "binance":
            message = "Missing dependency 'python-binance'. Run: pip install -r requirements.txt"
            logger.error("dependency_error", extra={"event": "dependency_error", "error": message})
            print(f"Failure: {message}", file=sys.stderr)
            return 1
        raise

    client = BinanceFuturesClient(
        api_key=args.api_key,
        api_secret=args.api_secret,
        base_url=args.base_url,
        recv_window=args.recv_window,
        timeout=args.timeout,
        max_retries=args.max_retries,
        logger=logger,
    )

    try:
        client.sync_time()
        account = client.get_account()
    except BinanceAPIError as exc:
        logger.error(
            "binance_api_error",
            extra={
                "event": "binance_api_error",
                "status_code": exc.status_code,
                "error": str(exc),
                "response": exc.payload,
            },
        )
        print(f"Failure: Binance API error: {exc}", file=sys.stderr)
        return 1
    except BinanceRequestError as exc:
        logger.error("network_error", extra={"event": "network_error", "error": str(exc)})
        print(f"Failure: Network error: {exc}", file=sys.stderr)
        return 1

    print("Account Link")
    print("------------")
    print(f"baseUrl: {args.base_url}")
    print(f"canTrade: {account.get('canTrade', 'N/A')}")
    print(f"accountAlias: {account.get('accountAlias', 'N/A')}")
    print(f"totalWalletBalance: {account.get('totalWalletBalance', 'N/A')}")
    print("\nSuccess: Binance Futures Testnet account linked.")
    return 0


def print_order_request(order_request: OrderRequest, *, dry_run: bool) -> None:
    print("Order Request")
    print("-------------")
    print(f"symbol: {order_request.symbol}")
    print(f"side: {order_request.side}")
    print(f"type: {order_request.order_type}")
    print(f"quantity: {order_request.quantity}")
    if order_request.price is not None:
        print(f"price: {order_request.price}")
    if order_request.order_type == "LIMIT":
        print(f"timeInForce: {order_request.time_in_force}")
    if order_request.position_side:
        print(f"positionSide: {order_request.position_side}")
    if order_request.reduce_only:
        print("reduceOnly: true")
    if order_request.client_order_id:
        print(f"newClientOrderId: {order_request.client_order_id}")
    print(f"newOrderRespType: {order_request.new_order_resp_type}")
    if dry_run:
        print("mode: dry-run")


def print_order_response(summary: dict[str, Any], raw_response: dict[str, Any]) -> None:
    print("\nOrder Response")
    print("--------------")
    for key in ("orderId", "status", "executedQty", "avgPrice"):
        print(f"{key}: {summary.get(key, 'N/A')}")
    print("\nRaw Response")
    print("------------")
    for key, value in raw_response.items():
        print(f"{key}: {value}")


def _printable_order(order_request: OrderRequest) -> dict[str, str | bool | None]:
    printable: dict[str, str | bool | None] = {}
    for key, value in asdict(order_request).items():
        if isinstance(value, Decimal):
            printable[key] = format(value, "f")
        else:
            printable[key] = value
    return printable


def _read_env_values(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for line in path.read_text(encoding="utf-8").splitlines():
        key, separator, value = line.partition("=")
        if separator and key and not key.lstrip().startswith("#"):
            values[key.strip()] = value.strip()
    return values


def _write_env_values(path: Path, values: dict[str, str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    ordered_keys = (
        "BINANCE_API_KEY",
        "BINANCE_API_SECRET",
        "BINANCE_FUTURES_BASE_URL",
    )
    lines = [f"{key}={values[key]}" for key in ordered_keys if key in values]
    extra_keys = sorted(key for key in values if key not in ordered_keys)
    lines.extend(f"{key}={values[key]}" for key in extra_keys)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
