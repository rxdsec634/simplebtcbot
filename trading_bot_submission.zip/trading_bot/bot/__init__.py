"""Core package for Binance Futures Testnet order placement."""
