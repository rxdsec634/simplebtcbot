from __future__ import annotations

from typing import Any


class TradingBotError(Exception):
    """Base exception for expected trading bot failures."""


class ValidationError(TradingBotError):
    """Raised when CLI input cannot produce a valid order request."""


class BinanceRequestError(TradingBotError):
    """Raised for network and transport failures."""


class BinanceAPIError(TradingBotError):
    """Raised when Binance returns a non-success status code."""

    def __init__(self, status_code: int, payload: Any):
        self.status_code = status_code
        self.payload = payload
        super().__init__(self._build_message())

    def _build_message(self) -> str:
        if isinstance(self.payload, dict):
            code = self.payload.get("code")
            message = self.payload.get("msg") or self.payload.get("message")
            if code is not None and message:
                return f"HTTP {self.status_code} Binance code {code}: {message}"
            if message:
                return f"HTTP {self.status_code}: {message}"
        return f"HTTP {self.status_code}: {self.payload}"
