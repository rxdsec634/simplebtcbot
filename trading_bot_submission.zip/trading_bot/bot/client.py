from __future__ import annotations

import logging
import time
from typing import Any, Callable

from binance.client import Client
from binance.exceptions import BinanceAPIException, BinanceRequestException

try:
    from requests import RequestException, Timeout
except ImportError:  # pragma: no cover - requests is installed by python-binance
    class RequestException(Exception):
        pass

    class Timeout(RequestException):
        pass

from .exceptions import BinanceAPIError, BinanceRequestError


RETRYABLE_STATUS_CODES = {408, 425, 429, 500, 502, 503, 504}


class BinanceFuturesClient:
    """Thin python-binance wrapper for Binance USDT-M Futures Testnet."""

    def __init__(
        self,
        *,
        api_key: str,
        api_secret: str,
        base_url: str = "https://testnet.binancefuture.com",
        recv_window: int = 5000,
        timeout: float = 10.0,
        max_retries: int = 2,
        logger: logging.Logger | None = None,
        sdk_client: Client | None = None,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.recv_window = recv_window
        self.timeout = timeout
        self.max_retries = max(0, max_retries)
        self.logger = logger or logging.getLogger("trading_bot")
        self.client = sdk_client or self._build_sdk_client(api_key, api_secret)

        # python-binance supports testnet=True, and this pins Futures calls to the
        # exact base URL required by the assignment.
        self.client.FUTURES_URL = f"{self.base_url}/fapi"

    def get_public(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        params = params or {}
        if path == "/fapi/v1/exchangeInfo":
            return self._call_with_logging(
                method="GET",
                path=path,
                params=params,
                call=lambda: self.client.futures_exchange_info(),
                safe_to_retry=True,
            )
        if path == "/fapi/v1/time":
            return self._call_with_logging(
                method="GET",
                path=path,
                params=params,
                call=self.client.futures_time,
                safe_to_retry=True,
            )
        raise BinanceRequestError(f"unsupported public futures endpoint: {path}")

    def post_signed(self, path: str, params: dict[str, Any]) -> dict[str, Any]:
        if path != "/fapi/v1/order":
            raise BinanceRequestError(f"unsupported signed POST futures endpoint: {path}")

        order_params = dict(params)
        order_params.setdefault("recvWindow", self.recv_window)
        return self._call_with_logging(
            method="POST",
            path=path,
            params=order_params,
            call=lambda: self.client.futures_create_order(**order_params),
            safe_to_retry=False,
        )

    def get_signed(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        if path != "/fapi/v1/order":
            raise BinanceRequestError(f"unsupported signed GET futures endpoint: {path}")

        request_params = dict(params or {})
        request_params.setdefault("recvWindow", self.recv_window)
        return self._call_with_logging(
            method="GET",
            path=path,
            params=request_params,
            call=lambda: self.client.futures_get_order(**request_params),
            safe_to_retry=True,
        )

    def get_account(self) -> dict[str, Any]:
        params = {"recvWindow": self.recv_window}
        return self._call_with_logging(
            method="GET",
            path="/fapi/v2/account",
            params=params,
            call=lambda: self.client.futures_account(**params),
            safe_to_retry=True,
            response_for_log=self._account_response_summary,
        )

    def sync_time(self) -> None:
        payload = self.get_public("/fapi/v1/time")
        server_time = payload.get("serverTime")
        if not isinstance(server_time, int):
            raise BinanceRequestError(f"unexpected server time payload: {payload!r}")

        local_time = int(time.time() * 1000)
        offset_ms = server_time - local_time
        setattr(self.client, "timestamp_offset", offset_ms)
        self.logger.info(
            "time_synced",
            extra={"event": "time_synced", "server_time": server_time, "offset_ms": offset_ms},
        )

    def _build_sdk_client(self, api_key: str, api_secret: str) -> Client:
        requests_params = {"timeout": self.timeout}
        try:
            return Client(
                api_key,
                api_secret,
                requests_params=requests_params,
                testnet=True,
                ping=False,
            )
        except TypeError:
            return Client(api_key, api_secret, requests_params=requests_params, testnet=True)

    def _call_with_logging(
        self,
        *,
        method: str,
        path: str,
        params: dict[str, Any],
        call: Callable[[], dict[str, Any]],
        safe_to_retry: bool,
        response_for_log: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        max_attempts = 1 + (self.max_retries if safe_to_retry else 0)
        attempt = 1

        while True:
            started = time.perf_counter()
            self.logger.info(
                "api_request",
                extra={
                    "event": "api_request",
                    "sdk": "python-binance",
                    "method": method,
                    "path": path,
                    "attempt": attempt,
                    "params": self._sanitize_params(params),
                },
            )

            try:
                payload = call()
            except BinanceAPIException as exc:
                duration_ms = round((time.perf_counter() - started) * 1000, 2)
                status_code = int(getattr(exc, "status_code", 0) or 0)
                error_payload = self._api_exception_payload(exc)
                self.logger.error(
                    "api_error",
                    extra={
                        "event": "api_error",
                        "sdk": "python-binance",
                        "method": method,
                        "path": path,
                        "attempt": attempt,
                        "status_code": status_code,
                        "duration_ms": duration_ms,
                        "response": error_payload,
                    },
                )
                if status_code in RETRYABLE_STATUS_CODES and attempt < max_attempts:
                    self._log_retry(method, path, attempt, f"HTTP {status_code}")
                    self._sleep_before_retry(attempt)
                    attempt += 1
                    continue
                raise BinanceAPIError(status_code, error_payload) from exc
            except (BinanceRequestException, Timeout, RequestException) as exc:
                if attempt < max_attempts:
                    self._log_retry(method, path, attempt, str(exc))
                    self._sleep_before_retry(attempt)
                    attempt += 1
                    continue
                self.logger.error(
                    "api_network_error",
                    extra={
                        "event": "api_network_error",
                        "sdk": "python-binance",
                        "method": method,
                        "path": path,
                        "attempt": attempt,
                        "error": str(exc),
                    },
                )
                raise BinanceRequestError(str(exc)) from exc

            duration_ms = round((time.perf_counter() - started) * 1000, 2)
            logged_response = response_for_log(payload) if response_for_log else payload
            self.logger.info(
                "api_response",
                extra={
                    "event": "api_response",
                    "sdk": "python-binance",
                    "method": method,
                    "path": path,
                    "attempt": attempt,
                    "duration_ms": duration_ms,
                    "response": logged_response,
                },
            )

            if not isinstance(payload, dict):
                raise BinanceRequestError(f"unexpected response payload from {path}: {payload!r}")
            return payload

    @staticmethod
    def _api_exception_payload(exc: BinanceAPIException) -> dict[str, Any]:
        return {
            "code": getattr(exc, "code", None),
            "msg": getattr(exc, "message", str(exc)),
        }

    @staticmethod
    def _sanitize_params(params: dict[str, Any]) -> dict[str, Any]:
        sanitized = dict(params)
        for key in ("signature", "api_key", "api_secret"):
            if key in sanitized:
                sanitized[key] = "***"
        return sanitized

    @staticmethod
    def _account_response_summary(payload: dict[str, Any]) -> dict[str, Any]:
        assets = payload.get("assets")
        positions = payload.get("positions")
        return {
            "accountAlias": payload.get("accountAlias"),
            "canTrade": payload.get("canTrade"),
            "totalWalletBalance": payload.get("totalWalletBalance"),
            "assetsCount": len(assets) if isinstance(assets, list) else None,
            "positionsCount": len(positions) if isinstance(positions, list) else None,
        }

    def _log_retry(self, method: str, path: str, attempt: int, reason: str) -> None:
        self.logger.warning(
            "api_retry",
            extra={
                "event": "api_retry",
                "sdk": "python-binance",
                "method": method,
                "path": path,
                "attempt": attempt,
                "next_attempt": attempt + 1,
                "reason": reason,
            },
        )

    @staticmethod
    def _sleep_before_retry(attempt: int) -> None:
        time.sleep(min(0.25 * (2 ** (attempt - 1)), 2.0))
