from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Any

from .exceptions import ValidationError
from .validators import OrderRequest, decimal_to_api_string


@dataclass(frozen=True)
class QuantityRules:
    min_qty: Decimal
    max_qty: Decimal
    step_size: Decimal


@dataclass(frozen=True)
class SymbolRules:
    symbol: str
    status: str
    min_price: Decimal
    max_price: Decimal
    tick_size: Decimal
    lot_size: QuantityRules
    market_lot_size: QuantityRules
    min_notional: Decimal

    @classmethod
    def from_exchange_info(cls, payload: dict[str, Any], symbol: str) -> "SymbolRules":
        symbol_info = _find_symbol_info(payload, symbol)
        filters = {
            item.get("filterType"): item
            for item in symbol_info.get("filters", [])
            if isinstance(item, dict)
        }

        price_filter = _required_filter(filters, "PRICE_FILTER", symbol)
        lot_size = _required_filter(filters, "LOT_SIZE", symbol)
        market_lot_size = filters.get("MARKET_LOT_SIZE", lot_size)
        min_notional_filter = filters.get("MIN_NOTIONAL") or filters.get("NOTIONAL") or {}

        return cls(
            symbol=symbol_info["symbol"],
            status=str(symbol_info.get("status", "")),
            min_price=_decimal_filter(price_filter, "minPrice"),
            max_price=_decimal_filter(price_filter, "maxPrice"),
            tick_size=_decimal_filter(price_filter, "tickSize"),
            lot_size=_quantity_rules(lot_size),
            market_lot_size=_quantity_rules(market_lot_size),
            min_notional=_decimal_filter(min_notional_filter, "notional", "minNotional"),
        )


def validate_order_against_exchange_filters(order: OrderRequest, rules: SymbolRules) -> None:
    if rules.status != "TRADING":
        raise ValidationError(f"{order.symbol} is not currently trading; status is {rules.status!r}")

    quantity_rules = rules.market_lot_size if order.order_type == "MARKET" else rules.lot_size
    _validate_range("quantity", order.quantity, quantity_rules.min_qty, quantity_rules.max_qty)
    _validate_increment("quantity", order.quantity, quantity_rules.step_size, "step size")

    if order.price is None:
        return

    _validate_range("price", order.price, rules.min_price, rules.max_price)
    _validate_increment("price", order.price, rules.tick_size, "tick size")

    if rules.min_notional > 0:
        notional = order.price * order.quantity
        if notional < rules.min_notional:
            raise ValidationError(
                "order notional must be at least "
                f"{decimal_to_api_string(rules.min_notional)}; got {decimal_to_api_string(notional)}"
            )


def _find_symbol_info(payload: dict[str, Any], symbol: str) -> dict[str, Any]:
    symbols = payload.get("symbols")
    if not isinstance(symbols, list):
        raise ValidationError("exchange info response did not include symbols")

    for item in symbols:
        if isinstance(item, dict) and item.get("symbol") == symbol:
            return item

    raise ValidationError(f"{symbol} was not found on Binance Futures Testnet")


def _required_filter(
    filters: dict[str | None, dict[str, Any]],
    filter_type: str,
    symbol: str,
) -> dict[str, Any]:
    filter_data = filters.get(filter_type)
    if not filter_data:
        raise ValidationError(f"{symbol} exchange info is missing {filter_type}")
    return filter_data


def _quantity_rules(filter_data: dict[str, Any]) -> QuantityRules:
    return QuantityRules(
        min_qty=_decimal_filter(filter_data, "minQty"),
        max_qty=_decimal_filter(filter_data, "maxQty"),
        step_size=_decimal_filter(filter_data, "stepSize"),
    )


def _decimal_filter(filter_data: dict[str, Any], *keys: str) -> Decimal:
    for key in keys:
        value = filter_data.get(key)
        if value is not None:
            return Decimal(str(value))
    return Decimal("0")


def _validate_range(name: str, value: Decimal, min_value: Decimal, max_value: Decimal) -> None:
    if min_value > 0 and value < min_value:
        raise ValidationError(
            f"{name} must be at least {decimal_to_api_string(min_value)}; "
            f"got {decimal_to_api_string(value)}"
        )
    if max_value > 0 and value > max_value:
        raise ValidationError(
            f"{name} must be at most {decimal_to_api_string(max_value)}; "
            f"got {decimal_to_api_string(value)}"
        )


def _validate_increment(name: str, value: Decimal, increment: Decimal, increment_name: str) -> None:
    if increment <= 0:
        return
    if value % increment != 0:
        raise ValidationError(
            f"{name} must align to {increment_name} {decimal_to_api_string(increment)}; "
            f"got {decimal_to_api_string(value)}"
        )
