from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from .exchange_filters import SymbolRules, validate_order_against_exchange_filters
from .validators import OrderRequest, decimal_to_api_string, ensure_client_order_id

if TYPE_CHECKING:
    from .client import BinanceFuturesClient


class OrderService:
    """Build and submit Binance Futures order requests."""

    def __init__(
        self,
        *,
        client: "BinanceFuturesClient",
        validate_exchange_filters: bool = True,
        sync_time: bool = True,
        logger: logging.Logger | None = None,
    ) -> None:
        self.client = client
        self.validate_exchange_filters = validate_exchange_filters
        self.sync_time = sync_time
        self.logger = logger or logging.getLogger("trading_bot")
        self._symbol_rules_cache: dict[str, SymbolRules] = {}

    def place_order(self, order: OrderRequest) -> dict[str, Any]:
        order = ensure_client_order_id(order)
        if self.validate_exchange_filters:
            rules = self._get_symbol_rules(order.symbol)
            validate_order_against_exchange_filters(order, rules)

        if self.sync_time:
            self.client.sync_time()

        params = self._to_binance_params(order)
        self.logger.info(
            "placing_order",
            extra={
                "event": "placing_order",
                "symbol": order.symbol,
                "side": order.side,
                "type": order.order_type,
                "client_order_id": order.client_order_id,
            },
        )
        return self.client.post_signed("/fapi/v1/order", params=params)

    def _get_symbol_rules(self, symbol: str) -> SymbolRules:
        rules = self._symbol_rules_cache.get(symbol)
        if rules is not None:
            return rules

        payload = self.client.get_public("/fapi/v1/exchangeInfo", params={"symbol": symbol})
        rules = SymbolRules.from_exchange_info(payload, symbol)
        self._symbol_rules_cache[symbol] = rules
        self.logger.info(
            "exchange_filters_loaded",
            extra={"event": "exchange_filters_loaded", "symbol": symbol, "status": rules.status},
        )
        return rules

    @staticmethod
    def _to_binance_params(order: OrderRequest) -> dict[str, Any]:
        params: dict[str, Any] = {
            "symbol": order.symbol,
            "side": order.side,
            "type": order.order_type,
            "quantity": decimal_to_api_string(order.quantity),
            "newOrderRespType": order.new_order_resp_type,
        }

        if order.order_type == "LIMIT":
            params["timeInForce"] = order.time_in_force
            params["price"] = decimal_to_api_string(order.price) if order.price is not None else None

        if order.position_side:
            params["positionSide"] = order.position_side
        if order.reduce_only:
            params["reduceOnly"] = "true"
        if order.client_order_id:
            params["newClientOrderId"] = order.client_order_id

        return params


def summarize_order_response(response: dict[str, Any]) -> dict[str, Any]:
    return {
        "orderId": response.get("orderId"),
        "status": response.get("status"),
        "executedQty": response.get("executedQty"),
        "avgPrice": response.get("avgPrice") or response.get("avgFillPrice"),
    }
