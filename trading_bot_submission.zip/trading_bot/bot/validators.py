from __future__ import annotations

import re
import uuid
from dataclasses import dataclass, replace
from decimal import Decimal, InvalidOperation

from .exceptions import ValidationError


VALID_SYMBOL_RE = re.compile(r"^[A-Z0-9]{5,30}$")
VALID_CLIENT_ORDER_ID_RE = re.compile(r"^[\.A-Z\:/a-z0-9_-]{1,36}$")
VALID_SIDES = {"BUY", "SELL"}
VALID_ORDER_TYPES = {"MARKET", "LIMIT"}
VALID_TIME_IN_FORCE = {"GTC", "IOC", "FOK", "GTX"}
VALID_POSITION_SIDES = {"BOTH", "LONG", "SHORT"}
VALID_RESPONSE_TYPES = {"ACK", "RESULT"}


@dataclass(frozen=True)
class OrderRequest:
    symbol: str
    side: str
    order_type: str
    quantity: Decimal
    price: Decimal | None = None
    time_in_force: str = "GTC"
    position_side: str | None = None
    reduce_only: bool = False
    client_order_id: str | None = None
    new_order_resp_type: str = "RESULT"


def validate_order_request(
    *,
    symbol: str,
    side: str,
    order_type: str,
    quantity: str,
    price: str | None = None,
    time_in_force: str = "GTC",
    position_side: str | None = None,
    reduce_only: bool = False,
    client_order_id: str | None = None,
    new_order_resp_type: str = "RESULT",
) -> OrderRequest:
    normalized_symbol = _required_upper("symbol", symbol)
    normalized_side = _required_upper("side", side)
    normalized_order_type = _required_upper("order type", order_type)
    normalized_time_in_force = _required_upper("time in force", time_in_force)
    normalized_position_side = _optional_upper(position_side)
    normalized_response_type = _required_upper("response type", new_order_resp_type)

    if not VALID_SYMBOL_RE.fullmatch(normalized_symbol):
        raise ValidationError(
            "symbol must be 5 to 30 uppercase letters or digits, for example BTCUSDT"
        )
    if normalized_side not in VALID_SIDES:
        raise ValidationError("side must be BUY or SELL")
    if normalized_order_type not in VALID_ORDER_TYPES:
        raise ValidationError("order type must be MARKET or LIMIT")
    if normalized_time_in_force not in VALID_TIME_IN_FORCE:
        raise ValidationError("time in force must be one of GTC, IOC, FOK, GTX")
    if normalized_position_side and normalized_position_side not in VALID_POSITION_SIDES:
        raise ValidationError("position side must be BOTH, LONG, or SHORT")
    if normalized_response_type not in VALID_RESPONSE_TYPES:
        raise ValidationError("response type must be ACK or RESULT")
    if client_order_id and not VALID_CLIENT_ORDER_ID_RE.fullmatch(client_order_id):
        raise ValidationError(
            "client order id must be 1 to 36 characters using letters, digits, '.', ':', '/', '_', or '-'"
        )

    parsed_quantity = _positive_decimal("quantity", quantity)

    parsed_price: Decimal | None = None
    if normalized_order_type == "LIMIT":
        if price is None:
            raise ValidationError("price is required for LIMIT orders")
        parsed_price = _positive_decimal("price", price)
    elif price is not None:
        raise ValidationError("price is only valid for LIMIT orders")

    return OrderRequest(
        symbol=normalized_symbol,
        side=normalized_side,
        order_type=normalized_order_type,
        quantity=parsed_quantity,
        price=parsed_price,
        time_in_force=normalized_time_in_force,
        position_side=normalized_position_side,
        reduce_only=reduce_only,
        client_order_id=client_order_id,
        new_order_resp_type=normalized_response_type,
    )


def ensure_client_order_id(order: OrderRequest) -> OrderRequest:
    if order.client_order_id:
        return order
    return replace(order, client_order_id=f"tb_{uuid.uuid4().hex[:24]}")


def decimal_to_api_string(value: Decimal) -> str:
    return format(value.normalize(), "f")


def _required_upper(name: str, value: str | None) -> str:
    if value is None or not str(value).strip():
        raise ValidationError(f"{name} is required")
    return str(value).strip().upper()


def _optional_upper(value: str | None) -> str | None:
    if value is None:
        return None
    stripped = str(value).strip()
    return stripped.upper() if stripped else None


def _positive_decimal(name: str, value: str | None) -> Decimal:
    if value is None or not str(value).strip():
        raise ValidationError(f"{name} is required")

    try:
        parsed = Decimal(str(value).strip())
    except InvalidOperation as exc:
        raise ValidationError(f"{name} must be a valid number") from exc

    if not parsed.is_finite() or parsed <= 0:
        raise ValidationError(f"{name} must be greater than zero")
    return parsed
