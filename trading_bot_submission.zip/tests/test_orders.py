from __future__ import annotations

import unittest

from trading_bot.bot.orders import OrderService
from trading_bot.bot.validators import validate_order_request


class FakeClient:
    def __init__(self) -> None:
        self.path: str | None = None
        self.params: dict[str, str] | None = None

    def post_signed(self, path: str, params: dict[str, str]) -> dict[str, str]:
        self.path = path
        self.params = params
        return {"orderId": "123", "status": "NEW", "executedQty": "0", "avgPrice": "0.00"}


class OrderServiceTests(unittest.TestCase):
    def test_market_order_payload(self) -> None:
        order = validate_order_request(
            symbol="btcusdt",
            side="buy",
            order_type="market",
            quantity="0.0010",
            client_order_id="market-test-1",
        )
        client = FakeClient()
        service = OrderService(client=client, validate_exchange_filters=False, sync_time=False)

        response = service.place_order(order)

        self.assertEqual(response["orderId"], "123")
        self.assertEqual(client.path, "/fapi/v1/order")
        self.assertEqual(
            client.params,
            {
                "symbol": "BTCUSDT",
                "side": "BUY",
                "type": "MARKET",
                "quantity": "0.001",
                "newOrderRespType": "RESULT",
                "newClientOrderId": "market-test-1",
            },
        )

    def test_limit_order_payload(self) -> None:
        order = validate_order_request(
            symbol="BTCUSDT",
            side="SELL",
            order_type="LIMIT",
            quantity="0.001",
            price="90000.00",
            time_in_force="GTC",
            client_order_id="limit-test-1",
        )
        client = FakeClient()
        service = OrderService(client=client, validate_exchange_filters=False, sync_time=False)

        service.place_order(order)

        self.assertEqual(
            client.params,
            {
                "symbol": "BTCUSDT",
                "side": "SELL",
                "type": "LIMIT",
                "quantity": "0.001",
                "newOrderRespType": "RESULT",
                "timeInForce": "GTC",
                "price": "90000",
                "newClientOrderId": "limit-test-1",
            },
        )


if __name__ == "__main__":
    unittest.main()
