from __future__ import annotations

import unittest

from trading_bot.bot.exceptions import ValidationError
from trading_bot.bot.validators import ensure_client_order_id, validate_order_request


class ValidatorTests(unittest.TestCase):
    def test_limit_requires_price(self) -> None:
        with self.assertRaisesRegex(ValidationError, "price is required"):
            validate_order_request(
                symbol="BTCUSDT",
                side="BUY",
                order_type="LIMIT",
                quantity="0.001",
            )

    def test_market_rejects_price(self) -> None:
        with self.assertRaisesRegex(ValidationError, "price is only valid"):
            validate_order_request(
                symbol="BTCUSDT",
                side="BUY",
                order_type="MARKET",
                quantity="0.001",
                price="90000",
            )

    def test_quantity_must_be_positive(self) -> None:
        with self.assertRaisesRegex(ValidationError, "quantity must be greater than zero"):
            validate_order_request(
                symbol="BTCUSDT",
                side="SELL",
                order_type="MARKET",
                quantity="0",
            )

    def test_generates_safe_client_order_id(self) -> None:
        order = validate_order_request(
            symbol="BTCUSDT",
            side="BUY",
            order_type="MARKET",
            quantity="0.001",
        )

        order = ensure_client_order_id(order)

        self.assertIsNotNone(order.client_order_id)
        self.assertRegex(order.client_order_id or "", r"^tb_[a-f0-9]{24}$")
        self.assertLessEqual(len(order.client_order_id or ""), 36)


if __name__ == "__main__":
    unittest.main()
