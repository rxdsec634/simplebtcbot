from __future__ import annotations

import unittest

from trading_bot.bot.exceptions import ValidationError
from trading_bot.bot.exchange_filters import SymbolRules, validate_order_against_exchange_filters
from trading_bot.bot.validators import validate_order_request


EXCHANGE_INFO = {
    "symbols": [
        {
            "symbol": "BTCUSDT",
            "status": "TRADING",
            "filters": [
                {
                    "filterType": "PRICE_FILTER",
                    "minPrice": "100.00",
                    "maxPrice": "1000000.00",
                    "tickSize": "0.10",
                },
                {
                    "filterType": "LOT_SIZE",
                    "minQty": "0.001",
                    "maxQty": "100",
                    "stepSize": "0.001",
                },
                {
                    "filterType": "MARKET_LOT_SIZE",
                    "minQty": "0.001",
                    "maxQty": "200",
                    "stepSize": "0.001",
                },
                {"filterType": "MIN_NOTIONAL", "notional": "5"},
            ],
        }
    ]
}


class ExchangeFilterTests(unittest.TestCase):
    def test_valid_limit_order_matches_filters(self) -> None:
        rules = SymbolRules.from_exchange_info(EXCHANGE_INFO, "BTCUSDT")
        order = validate_order_request(
            symbol="BTCUSDT",
            side="BUY",
            order_type="LIMIT",
            quantity="0.001",
            price="90000.10",
        )

        validate_order_against_exchange_filters(order, rules)

    def test_rejects_bad_price_tick(self) -> None:
        rules = SymbolRules.from_exchange_info(EXCHANGE_INFO, "BTCUSDT")
        order = validate_order_request(
            symbol="BTCUSDT",
            side="BUY",
            order_type="LIMIT",
            quantity="0.001",
            price="90000.11",
        )

        with self.assertRaisesRegex(ValidationError, "tick size"):
            validate_order_against_exchange_filters(order, rules)

    def test_rejects_bad_quantity_step(self) -> None:
        rules = SymbolRules.from_exchange_info(EXCHANGE_INFO, "BTCUSDT")
        order = validate_order_request(
            symbol="BTCUSDT",
            side="SELL",
            order_type="MARKET",
            quantity="0.0015",
        )

        with self.assertRaisesRegex(ValidationError, "step size"):
            validate_order_against_exchange_filters(order, rules)


if __name__ == "__main__":
    unittest.main()
